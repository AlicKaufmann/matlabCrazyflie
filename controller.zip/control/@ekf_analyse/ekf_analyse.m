classdef ekf_analyse
    methods
        % constructor, takes states and covariance matrices as arg. xTrue
        % is the true values of the states and x the one we estimated
        function obj = ekf_analyse(xTrue,x,P)
            % statess
            obj.xTrue = xTrue;
            obj.xEst = x;
            
            % errors
            error = sum((xTrue-x).^2, 2);
            obj.error_px = error(1);
            obj.error_py = error(2);
            obj.error_theta = error(3);
            obj.error_vx = error(4);
            obj.error_vy = error(5);
            obj.error_omega = error(6);
        end
        
        function f = plot_px(obj)
            f = figure;
            hold on
            plot(obj.xTrue(1,:))
            plot(obj.xEst(1,:))
            legend('true px', 'estimated px')
        end
        
        function f = plot_py(obj)
            f = figure;
            hold on
            plot(obj.xTrue(2,:))
            plot(obj.xEst(2,:))
            legend('true py', 'estimated py')
        end
        
        function f = plot_theta(obj)
            f = figure;
            hold on
            plot(obj.xTrue(3,:))
            plot(obj.xEst(3,:))
            legend('true theta', 'estimated theta')
        end
        
        function f = plot_vx(obj)
            f = figure;
            hold on
            plot(obj.xTrue(4,:))
            plot(obj.xEst(4,:))
            legend('true vx', 'estimated vx')
        end
        
        function f = plot_vy(obj)
            f = figure;
            hold on
            plot(obj.xTrue(5,:))
            plot(obj.xEst(5,:))
            legend('true vy', 'estimated vy')
        end
        
        function f = plot_omega(obj)
            f = figure;
            hold on
            plot(obj.xTrue(6,:))
            plot(obj.xEst(6,:))
            legend('true omega', 'estimated omega')
        end
        
        function f = plot_trajectory(obj)
            f = figure;
            hold on
            plot(obj.xTrue(1,:), obj.xTrue(2,:))
            plot(obj.xEst(1,:), obj.xEst(2,:))
            legend('true trajectory', 'trajectory with ekf')
        end
        
    end
    properties
        % states
        xTrue
        xEst
        
        % errors
        error_px
        error_py
        error_theta
        error_vx
        error_vy
        error_omega
    end
end