classdef hovercraft_model
    methods
        % constructor
        function obj = hovercraft_model()
            import casadi.*
            
            u = MX.sym('u',2); % control input, u = [uT, UR],parameter for the integration
            px = MX.sym('px',1);
            py = MX.sym('py',1);
            theta = MX.sym('theta',1);
            vx = MX.sym('vx', 1);
            vy = MX.sym('vy', 1);
            omega = MX.sym('omega',1);
            
            transMap = casadi.interpolant('LUT','bspline',{[0,2,3,5,6,7,8,9,10]}, [0,0.2244,0.3850,0.6309,0.7839,1.022,1.1630,1.3959,1.5340]);
            rotMap = casadi.interpolant('LUT','bspline',{0:10:100}, [0, 6.3632, 16.8374, 25.6822, 35.5810, 45.7588, 53.0103, 60.5996, 83.5957, 89.0708, 96.1055]);
            
            states = [px;py;theta;vx;vy;omega];
            rhs = [vx;...
                vy;...
                omega;...
                transMap(u(1))*cos(theta + pi/2);...
                transMap(u(1))*sin(theta + pi/2);...
                rotMap(u(2))];
            
            obj.f = Function('f',{states,u},{rhs},{'x','u'},{'rhs'}); % fonction of the dynamics
            obj.h = Function('h',{states},{states([1,2,3,6])}); % measurment function
        end
    end
    properties
        % transition and measurment maps
        f
        h
    end
end