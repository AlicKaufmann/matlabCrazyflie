
function x = validate_kalman()
% validate_kalman() creates the trajectory we want and returns its states

N = 101;
T = 10;
t = linspace(0, T, N);
dt = t(2) - t(1);
vx = -sin(t);
vy = cos(t);
px = cos(t);
py = sin(t);
ax = -cos(t);
ay = -sin(t);
theta = t + pi/2; % linear increase of the angle because speed on circle is constant
% theta = atan2(ay,ax);
omega = gradient(theta, t);

x = [px; py; theta; vx; vy; omega];

% simulate real measurments
noise_prefac = 0.02;

% if we give the correct measurments shifted by some random noise
noise = noise_prefac * (rand(4, N)-0.5);
y = [px; py; theta; omega] + noise;


